import torch
import torch.nn as nn
import random
import tqdm
from copy import deepcopy

from datasets import load_dataset
from data_process import get_corefs

class Trainer:
    def __init__(self, args, model):
        self.args = args
        self.model = model

        self.train_data = list(args.train_data)
        self.val_data = args.val_data
        self.test_data = args.test_data

        self.model = model.to(args.device)
        self.optimizer = torch.optim.Adam(params=[p for p in self.model.parameters() if p.requires_grad], lr=args.lr)
        self.scheduler = torch.optim.lr_scheduler.StepLR(self.optimizer, step_size=args.step_size, gamma=args.gamma)

    def train(self):
        # Train the model
        for epoch in tqdm.tqdm(range(self.args.epochs)):
            self.model.train()

            total_loss, total_mentions, total_corefs, total_identified = 0, 0, 0, 0

            # choosing 100 random documents
            random_docs = random.sample(self.train_data, 100)
            loss, mentions, corefs, identified = [], [], [], []

            for doc_ in tqdm.tqdm(random_docs):
                # make a copy of the document
                doc = deepcopy(doc_)
                doc = doc.crop_sents()

                corefs, mentions = get_corefs(doc)

                self.optimizer.zero_grad()
                mentions, corefs, identified = 0, 0, 0
                spans, probs = self.model(doc)

                links = torch.zeros_like(probs).to(self.args.device)

                for id_, span in enumerate(spans):
                    if (span.i, span.j) in corefs:
                        mentions += 1
                        gold = [i for i, link in enumerate(span.yi_idx) if link in corefs]

                        if gold:
                            links[id_, gold] = 1
                            corefs = sum((probs[id_, gold] > probs[id_, len(span.yi_idx)])).detach()
                            identified += corefs.item()
                        else:
                            links[id_, len(span.yi_idx)] = 1

                eps = 1e-8

                loss = torch.sum(torch.log(torch.sum(torch.mul(probs, links), dim=1).clamp(eps, 1-eps), dim=0) * -1)
                loss.backward()
                self.optimizer.step()

                total_loss += loss.item()
                total_mentions += mentions
                total_corefs += len(corefs)
                total_identified += identified

            print(f"Epoch: {epoch}, Loss: {total_loss}, Mentions: {total_mentions}, Corefs: {total_corefs}, Identified: {total_identified}")

    def evaluate(self):
        # Evaluate the model
        pass

    def predict(self):
        # Predict on new data
        pass
