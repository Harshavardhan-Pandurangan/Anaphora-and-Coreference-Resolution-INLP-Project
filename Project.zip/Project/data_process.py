import torch
import random
import tqdm
import os
from fnmatch import fnmatch
from boltons.iterutils import pairwise
import re
from datasets import load_dataset
from itertools import combinations
from utils import Span, convert_idx_spans
from cached_property import cached_property

def flatten(list_):
    return [item for sublist in list_ for item in sublist]

def clean_token(token):
    NORMALIZE_DICT = {"/.": ".", "/?": "?",
                      "-LRB-": "(", "-RRB-": ")",
                      "-LCB-": "{", "-RCB-": "}",
                      "-LSB-": "[", "-RSB-": "]"}
    REMOVED_CHAR = ["/", "%", "*"]

    if token in NORMALIZE_DICT:
        token = NORMALIZE_DICT[token]

    if token not in REMOVED_CHAR:
        for char in REMOVED_CHAR:
            token = token.replace(char, "")

    if len(token) > 0:
        return token
    else:
        return ','

class Corpus:
    def __init__(self, documents):
        self.docs = documents

        vocab, char_vocab = set(), set()

        for document in self.docs:
            vocab.update(document.tokens)
            char_vocab.update([char
                               for word in document.tokens
                               for char in word])

        self.vocab, self.char_vocab = vocab, char_vocab

    def __getitem__(self, idx):
        return self.docs[idx]

class Document:
    def __init__(self, raw, tokens, corefs, speakers, filename):
        self.raw = raw
        self.tokens = tokens
        self.corefs = corefs
        self.speakers = speakers
        self.filename = filename

    def __getitem__(self, idx):
        return self.tokens[idx], self.corefs[idx], self.speakers[idx]

    def __len__(self):
        return len(self.tokens)

    @cached_property
    def sentences(self):
        idx = [id_+1 for id_, token in enumerate(self.tokens) if token in ['.', '?', '!']]
        return [self.tokens[i:j] for i, j in pairwise([0] + idx)]

    def spans(self):
        spans = [Span(i, j, id_, self.speaker(i)) for id_, (i, j) in enumerate(convert_idx_spans(self.corefs))]

    def crop_sents(self, max_sents=50):
        if len(self.sentences) > max_sents:
            indices = random.sample(range(max_sents, len(self.sentences)), 1)
            tokens = flatten(self.sentences[indices[0]-max_sents:indices[0]])

            return self.__class__(self.raw, tokens, self.corefs, self.speakers, self.filename)
        else:
            return self

    def speaker(self, i):
        if self.speakers[i[0]] == self.speakers[i[1]]:
            return self.speakers[i[0]]
        else:
            return 0

def load_data(args):
    data_dir = args.data_dir
    train_path = os.path.join(data_dir, "v12/data/train")
    val_path = os.path.join(data_dir, "v12/data/development")
    test_path = os.path.join(data_dir, "v12/data/test")

    train_files = []
    for path, subdirs, files in os.walk(train_path):
        for name in files:
            if fnmatch(name, "*gold_conll"):
                train_files.append(os.path.join(path, name))

    val_files = []
    for path, subdirs, files in os.walk(val_path):
        for name in files:
            if fnmatch(name, "*gold_conll"):
                val_files.append(os.path.join(path, name))

    test_files = []
    for path, subdirs, files in os.walk(test_path):
        for name in files:
            if fnmatch(name, "*gold_conll"):
                test_files.append(os.path.join(path, name))

    train_data = []
    train_documents = []
    for file in train_files:
        with open(file, 'rt', encoding='utf-8', errors='strict') as f:
            raw, tokens, text, ut_coref, ut_speaker, corefs, index = [], [], [], [], [], [], 0
            for line in f:
                raw.append(line)
                line = line.split()

                if len(line) == 0:
                    if text:
                        tokens.extend(text), ut_coref.extend(corefs), ut_speaker.extend([speaker] * len(text))
                        text, corefs = [], []
                        continue

                elif len(line) == 2:
                    doc = Document(raw, tokens, ut_coref, ut_speaker, file)
                    train_documents.append(doc)
                    raw, tokens, text, ut_coref, ut_speaker, index = [], [], [], [], [], 0

                elif len(line) > 7:
                    text.extend(clean_token(line[3]))
                    speaker = line[9]

                    if line[-1] != u'-':
                        coref_ = line[-1].split(u'|')
                        for token in coref_:
                            reg_match  = re.match(r"(\(?)(\d+)(\)?)$", token)
                            label = reg_match.group(2)

                            if reg_match.group(1) == "(":
                                corefs.append({"start": index, "end": None, "label": label})
                            if reg_match.group(3) == ")":
                                for i in range(len(corefs)-1, -1, -1):
                                    if corefs[i]["label"] == label and corefs[i]["end"] is None:
                                        break

                                corefs[i].update({"end": index, "span": (corefs[i]["start"], index)})
                    index += 1

                else:
                    continue

    train_data = Corpus(train_documents)

    val_data = []
    val_documents = []
    for file in val_files:
        with open(file, 'rt', encoding='utf-8', errors='strict') as f:
            raw, tokens, text, ut_coref, ut_speaker, corefs, index = [], [], [], [], [], [], 0
            for line in f:
                raw.append(line)
                line = line.split()

                if len(line) == 0:
                    if text:
                        tokens.extend(text), ut_coref.extend(corefs), ut_speaker.extend([speaker] * len(text))
                        text, corefs = [], []
                        continue

                elif len(line) == 2:
                    doc = Document(raw, tokens, ut_coref, ut_speaker, file)
                    val_documents.append(doc)
                    raw, tokens, text, ut_coref, ut_speaker, index = [], [], [], [], [], 0

                elif len(line) > 7:
                    text.extend(clean_token(line[3]))
                    speaker = line[9]

                    if line[-1] != "-":
                        coref_ = line[-1].split("|")
                        for token in coref_:
                            reg_match  = re.match(r"(\(?)(\d+)(\)?)$", token)
                            label = reg_match.group(2)

                            if reg_match.group(1) == "(":
                                corefs.append({"start": index, "end": None, "label": label})
                            if reg_match.group(3) == ")":
                                for i in range(len(corefs)-1, -1, -1):
                                    if corefs[i]["label"] == label and corefs[i]["end"] is None:
                                        break

                                corefs[i].update({"end": index, "span": (corefs[i]["start"], index)})
                    index += 1

                else:
                    continue

    val_data = Corpus(val_documents)

    test_data = []
    test_documents = []
    for file in test_files:
        with open(file, 'rt', encoding='utf-8', errors='strict') as f:
            raw, tokens, text, ut_coref, ut_speaker, corefs, index = [], [], [], [], [], [], 0
            for line in f:
                raw.append(line)
                line = line.split()

                if len(line) == 0:
                    if text:
                        tokens.extend(text), ut_coref.extend(corefs), ut_speaker.extend([speaker] * len(text))
                        text, corefs = [], []
                        continue

                elif len(line) == 2:
                    doc = Document(raw, tokens, ut_coref, ut_speaker, file)
                    test_documents.append(doc)
                    raw, tokens, text, ut_coref, ut_speaker, index = [], [], [], [], [], 0

                elif len(line) > 7:
                    text.extend(clean_token(line[3]))
                    speaker = line[9]

                    if line[-1] != "-":
                        coref_ = line[-1].split("|")
                        for token in coref_:
                            reg_match  = re.match(r"(\(?)(\d+)(\)?)$", token)
                            label = reg_match.group(2)

                            if reg_match.group(1) == "(":
                                corefs.append({"start": index, "end": None, "label": label})
                            if reg_match.group(3) == ")":
                                for i in range(len(corefs)-1, -1, -1):
                                    if corefs[i]["label"] == label and corefs[i]["end"] is None:
                                        break

                                corefs[i].update({"end": index, "span": (corefs[i]["start"], index)})
                    index += 1

                else:
                    continue

    test_data = Corpus(test_documents)

    return train_data, val_data, test_data

def get_vocab(data):
    vocab = set()
    for doc in data:
        for sent in doc["sentences"]:
            for word in sent["words"]:
                vocab.add(word)

    return vocab

def get_corefs(doc):
    mentions = set([coref["label"] for coref in doc.corefs])

    links = {}
    for coref in doc.corefs:
        label, span = coref["label"], coref["span"]
        links[label] = span

    corefs = flatten([[coref for coref in combinations(mentions, 2)] for mentions in links.values()])
    corefs = sorted(corefs)

    return corefs, mentions
